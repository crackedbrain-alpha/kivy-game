#  // import modules
import pgzrun
from random import randint
import pygame
import math
#  // initilize 'Actor' variables
Background = Actor("grassbackground")
playerTower = Actor("playertower")
laserManBuy = Actor("lasermanbuy")
shockManBuy = Actor("shockmanbuy")
plasmaManBuy = Actor("plasmamanbuy")
goldIcon=Actor("gold")
#  // position Actors
Background.x=1804
playerTower.pos=120,300
plasmaManBuy.pos = 200,560
laserManBuy.pos = 400,560
shockManBuy.pos = 600,560
money = 50000000000
#  // resize screen
WIDTH = 1200
HEIGHT = 600
#  // initilize lists
laserMans=[]
enemyLaserMans=[]
enemyLasers=[]
lasers=[]
plasmaMans=[]   
plasmas=[]
enemyPlasmaMans=[]
enemyPlasmas=[]
shocks=[]
enemyShocks=[]
enemyShockMans=[]
shockMans=[]
# game variables    
playerTowerHealth=300
music.set_volume(0.2)
music.play("shootermusic")
class plasmaMan:
    Act=Actor("plasmaman")
    health=200
    unit_disabled = True
    canmove=True
    enemy_detected = False
    reloadTimer=0
class shockMan:
    Act=Actor("shockman")
    health=225
    unit_disabled = True
    canmove=True
    enemy_detected = False
    reloadTimer=0
class enemyShockMan:
    Act=Actor("enemyshockman")
    health=190
    unit_disabled = True
    canmove=True
    enemy_detected = False
    reloadTimer=0
class enemyPlasmaMan:
    Act=Actor("enemyplasmaman")
    health=200
    enemy_detected = False
    reloadTimer=0
    unit_disabled=False
def spawnPlasmaMan():
    unit= plasmaMan()
    unit.Act=Actor("plasmaman")
    unit.health=200
    reloadTimer=0
    canmove=True
    enemy_detected = False
    plasmaMans.append(unit)
def spawnEnemyPlasmaMan(x,y):
    unit= enemyPlasmaMan()
    unit.Act=Actor("enemyplasmaman")
    unit.health=140
    unit.reloadTimer=0
    unit.enemy_detected = False
    unit.Act.y=y
    unit.Act.x=x
    unit.hasGem=False
    enemyPlasmaMans.append(unit)
def spawnEnemyShockMan(x,y):
    unit= enemyShockMan()
    unit.Act=Actor("enemyshockman")
    unit.health=190
    unit.reloadTimer=0
    unit.enemy_detected = False
    unit.Act.y=y
    unit.Act.x=x
    unit.hasGem=False
    enemyShockMans.append(unit)
def spawnShockMan():
    unit= shockMan()
    unit.Act=Actor("shockman")
    unit.health=225
    reloadTimer=0
    canmove=True
    hasGem=False
    enemy_detected = False
    shockMans.append(unit)
class laserMan:
    Act=Actor("enemylaserman")
    health=230
    unit_disabled = True
    canmove=True
    enemy_detected = False
    reloadTimer=0
class enemyLaserMan:
    Act=Actor("plasmaman")
    health=200
    enemy_detected = False
    reloadTimer=0
    hasGem=False
    unit_disabled=False
def spawnLaserMan():
    unit= laserMan()
    unit.Act=Actor("laserman")
    unit.health=230
    reloadTimer=0
    canmove=True
    hasGem=False
    enemy_detected = False
    laserMans.append(unit)
def spawnEnemyLaserMan(x,y):
    unit= enemyLaserMan()
    unit.Act=Actor("enemylaserman")
    unit.health=200
    unit.reloadTimer=0
    unit.enemy_detected = False
    unit.Act.y=y
    unit.Act.x=x
    unit.hasGem=False
    enemyLaserMans.append(unit)
spawnEnemyPlasmaMan(3000,380)
spawnEnemyPlasmaMan(3000,480)
spawnEnemyPlasmaMan(3000,580)
spawnEnemyPlasmaMan(4000,480)
spawnEnemyLaserMan(4300,480)
spawnEnemyLaserMan(4700,480)
spawnEnemyLaserMan(5000,480)
spawnEnemyLaserMan(5600,480)
spawnEnemyLaserMan(6000,480)
spawnEnemyLaserMan(7000,480)
spawnEnemyLaserMan(6700,480)
spawnEnemyShockMan(7000,480)
def update_units():
    for enemyPlasmaMan in enemyPlasmaMans:
        if enemyPlasmaMan.health<0:
            if enemyPlasmaMan.Act.image=="enemydead4":
                enemyPlasmaMans.remove(enemyPlasmaMan)
            if enemyPlasmaMan.Act.image=="enemydead3":
                enemyPlasmaMan.Act.image="enemydead4"
            if enemyPlasmaMan.Act.image=="enemydead2":
                enemyPlasmaMan.Act.image="enemydead3"
            if enemyPlasmaMan.Act.image=="enemydead1":
                enemyPlasmaMan.Act.image="enemydead2"
            if enemyPlasmaMan.Act.image=="enemyplasmaman":
                enemyPlasmaMan.Act.image="enemydead1"
            
        if enemyPlasmaMan.health>0:
            enemyPlasmaMan.Act.image="rangedetect"
            enemyPlasmaMan.Act.x-=255
            ### detection

            if plasmaMans == [] and laserMans==[] and shockMans==[]:
                enemyPlasmaMan.unit_disabled=False
            else:
                enemyPlasmaMan.unit_disabled=False
                for plasmaMan in plasmaMans:
                    if enemyPlasmaMan.reloadTimer == 0 and enemyPlasmaMan.Act.colliderect(plasmaMan.Act) and plasmaMan.unit_disabled == False:
                        shootEnemyPlasma(enemyPlasmaMan.Act.x+265,enemyPlasmaMan.Act.y)
                        sounds.plasmashot.play()
                        enemyPlasmaMan.reloadTimer = 175
                    if enemyPlasmaMan.Act.colliderect(plasmaMan.Act)and plasmaMan.unit_disabled == False:
                        enemyPlasmaMan.unit_disabled=True	                      
                for laserMan in laserMans:
                    if enemyPlasmaMan.reloadTimer == 0 and enemyPlasmaMan.Act.colliderect(laserMan.Act) and laserMan.unit_disabled == False:
                        shootEnemyPlasma(enemyPlasmaMan.Act.x+265,enemyPlasmaMan.Act.y)
                        sounds.plasmashot.play()
                        enemyPlasmaMan.reloadTimer = 175
                    if enemyPlasmaMan.Act.colliderect(laserMan.Act)and laserMan.unit_disabled == False:
                        enemyPlasmaMan.unit_disabled=True
                for shockMan in shockMans:
                    if enemyPlasmaMan.reloadTimer == 0 and enemyPlasmaMan.Act.colliderect(shockMan.Act) and shockMan.unit_disabled == False:
                        shootEnemyPlasma(enemyPlasmaMan.Act.x+265,enemyPlasmaMan.Act.y)
                        sounds.plasmashot.play()
                        enemyPlasmaMan.reloadTimer = 175
                    if enemyPlasmaMan.Act.colliderect(shockMan.Act)and shockMan.unit_disabled == False:
                        enemyPlasmaMan.unit_disabled=True	                      


            if enemyPlasmaMan.reloadTimer>0:    
                enemyPlasmaMan.reloadTimer-=1
            if enemyPlasmaMan.reloadTimer == 50:
                sounds.plasmareload.play()
            if enemyPlasmaMan.unit_disabled==False:
                enemyPlasmaMan.Act.x-=3
            if enemyPlasmaMan.health<140:
                enemyPlasmaMan.health+=0.04
            enemyPlasmaMan.Act.image="enemyplasmaman"
            enemyPlasmaMan.Act.x+=255
##############################
    for enemyShockMan in enemyShockMans:
        if enemyShockMan.health<0:
            if enemyShockMan.Act.image=="enemydead4":
                enemyShockMans.remove(enemyShockMan)
            if enemyShockMan.Act.image=="enemydead3":
                enemyShockMan.Act.image="enemydead4"
            if enemyShockMan.Act.image=="enemydead2":
                enemyShockMan.Act.image="enemydead3"
            if enemyShockMan.Act.image=="enemydead1":
                enemyShockMan.Act.image="enemydead2"
            if enemyShockMan.Act.image=="enemyshockman":
                enemyShockMan.Act.image="enemydead1"
        if enemyShockMan.health>0:
            enemyShockMan.Act.image="rangedetect"
            enemyShockMan.Act.x-=255
            ### detection

            if plasmaMans == [] and laserMans==[] and shockMans==[]:
                enemyShockMan.unit_disabled=False
            else:
                enemyShockMan.unit_disabled=False
                for plasmaMan in plasmaMans:
                    if enemyShockMan.reloadTimer == 0 and enemyShockMan.Act.colliderect(plasmaMan.Act) and plasmaMan.unit_disabled == False:
                        shootEnemyShock(enemyShockMan.Act.x+265,enemyShockMan.Act.y)
                        sounds.shockshot.play()
                        enemyShockMan.reloadTimer = 175
                    if enemyShockMan.Act.colliderect(plasmaMan.Act)and plasmaMan.unit_disabled == False:
                        enemyShockMan.unit_disabled=True	                      
                for laserMan in laserMans:
                    if enemyShockMan.reloadTimer == 0 and enemyShockMan.Act.colliderect(laserMan.Act) and laserMan.unit_disabled == False:
                        shootEnemyShock(enemyShockMan.Act.x+265,enemyShockMan.Act.y)
                        sounds.shockshot.play()
                        enemyShockMan.reloadTimer = 175
                    if enemyShockMan.Act.colliderect(laserMan.Act)and laserMan.unit_disabled == False:
                        enemyShockMan.unit_disabled=True
                for shockMan in shockMans:
                    if enemyShockMan.reloadTimer == 0 and enemyShockMan.Act.colliderect(shockMan.Act) and shockMan.unit_disabled == False:
                        shootEnemyShock(enemyShockMan.Act.x+265,enemyShockMan.Act.y)
                        sounds.plasmashot.play()
                        enemyShockMan.reloadTimer = 175
                    if enemyShockMan.Act.colliderect(shockMan.Act)and shockMan.unit_disabled == False:
                        enemyShockMan.unit_disabled=True	                      


            if enemyShockMan.reloadTimer>0:    
                enemyShockMan.reloadTimer-=1
            if enemyShockMan.reloadTimer == 50:
                sounds.shockreload.play()
            if enemyShockMan.unit_disabled==False:
                enemyShockMan.Act.x-=3
            if enemyShockMan.health<190:
                enemyShockMan.health+=0.04
            enemyShockMan.Act.image="enemyshockman"
            enemyShockMan.Act.x+=255
            
    for enemyLaserMan in enemyLaserMans:
        if enemyLaserMan.health<0:
            if enemyLaserMan.Act.image=="enemydead4":
                enemyLaserMans.remove(enemyLaserMan)
            if enemyLaserMan.Act.image=="enemydead3":
                enemyLaserMan.Act.image="enemydead4"
            if enemyLaserMan.Act.image=="enemydead2":
                enemyLaserMan.Act.image="enemydead3"
            if enemyLaserMan.Act.image=="enemydead1":
                enemyLaserMan.Act.image="enemydead2"
            if enemyLaserMan.Act.image=="enemylaserman":
                enemyLaserMan.Act.image="enemydead1"
            
        if enemyLaserMan.health>0:
            enemyLaserMan.Act.image="rangedetect"
            enemyLaserMan.Act.x-=255
            ### detection

            if plasmaMans == [] and laserMans==[] and shockMans==[]:
                enemyLaserMan.unit_disabled=False
            else:
                enemyLaserMan.unit_disabled=False
                for plasmaMan in plasmaMans:
                    if enemyLaserMan.reloadTimer == 0 and enemyLaserMan.Act.colliderect(plasmaMan.Act) and plasmaMan.unit_disabled == False:
                        shootEnemyLaser(enemyLaserMan.Act.x+265,enemyLaserMan.Act.y)
                        sounds.lasershot.play()
                        enemyLaserMan.reloadTimer = 175
                    if enemyLaserMan.Act.colliderect(plasmaMan.Act)and plasmaMan.unit_disabled == False:
                        enemyLaserMan.unit_disabled=True	                      
                for laserMan in laserMans:
                    if enemyLaserMan.reloadTimer == 0 and enemyLaserMan.Act.colliderect(laserMan.Act) and laserMan.unit_disabled == False:
                        shootEnemyLaser(enemyLaserMan.Act.x+265,enemyLaserMan.Act.y)
                        sounds.lasershot.play()
                        enemyLaserMan.reloadTimer = 175
                    if enemyLaserMan.Act.colliderect(laserMan.Act)and laserMan.unit_disabled == False:
                        enemyLaserMan.unit_disabled=True	                      

                for shockMan in shockMans:
                    if enemyLaserMan.reloadTimer == 0 and enemyLaserMan.Act.colliderect(shockMan.Act) and shockMan.unit_disabled == False:
                        shootEnemyLaser(enemyLaserMan.Act.x+265,enemyLaserMan.Act.y)
                        sounds.lasershot.play()
                        enemyLaserMan.reloadTimer = 175
                    if enemyLaserMan.Act.colliderect(shockMan.Act)and shockMan.unit_disabled == False:
                        enemyLaserMan.unit_disabled=True	                      


            if enemyLaserMan.reloadTimer>0:    
                enemyLaserMan.reloadTimer-=1
            if enemyLaserMan.reloadTimer == 50:
                sounds.laserreload.play()
            if enemyLaserMan.unit_disabled==False:
                enemyLaserMan.Act.x-=3
            if enemyLaserMan.health<140:
                enemyLaserMan.health+=0.04
            enemyLaserMan.Act.image="enemylaserman"
            enemyLaserMan.Act.x+=255






    for laserMan in laserMans:
        if laserMan.health<0:
            if laserMan.Act.image=="dead4":
                laserMans.remove(laserMan)
            if laserMan.Act.image=="dead3":
                laserMan.Act.image="dead4"
            if laserMan.Act.image=="dead2":
                laserMan.Act.image="dead3"
            if laserMan.Act.image=="dead1":
                laserMan.Act.image="dead2"
            if laserMan.Act.image=="laserman":
                laserMan.Act.image="dead1"
        else:
            if laserMan.unit_disabled == True:
                laserMan.Act.pos = pygame.mouse.get_pos()
                if keyboard.space:
                    sounds.laserreload.play()
                    laserMan.unit_disabled = False
            
            else:
                laserMan.Act.image="rangedetect"
                laserMan.Act.x+=285
                ### detection
                if enemyPlasmaMans == [] and enemyLaserMans==[]:
                    laserMan.canmove=True
                else:
                    laserMan.canmove=True
                    for enemyPlasmaMan in enemyPlasmaMans:
                        if laserMan.reloadTimer == 0 and laserMan.Act.colliderect(enemyPlasmaMan.Act):
                            shootLaser(laserMan.Act.x-280,laserMan.Act.y)
                            sounds.lasershot.play()
                            laserMan.reloadTimer=175
                        if enemyPlasmaMan.Act.colliderect(laserMan.Act) :
                            laserMan.canmove=False
                            
                    for enemyLaserMan in enemyLaserMans:
                        if laserMan.reloadTimer == 0 and laserMan.Act.colliderect(enemyLaserMan.Act):
                            shootLaser(laserMan.Act.x-400,laserMan.Act.y)
                            sounds.lasershot.play()
                            laserMan.reloadTimer=185
                        if enemyLaserMan.Act.colliderect(laserMan.Act) :
                            laserMan.canmove=False

                    
                    for enemyShockMan in enemyShockMans:
                        if laserMan.reloadTimer == 0 and laserMan.Act.colliderect(enemyShockMan.Act):
                            shootLaser(laserMan.Act.x-400,laserMan.Act.y)
                            sounds.lasershot.play()
                            laserMan.reloadTimer=185
                        if enemyShockMan.Act.colliderect(laserMan.Act) :
                            laserMan.canmove=False
                if laserMan.canmove==True:
                    laserMan.Act.x+=4
            # reload
                if laserMan.reloadTimer == 140:
                    sounds.laserreload.play()
                if laserMan.health<230:
                    laserMan.health+=0.08
                if laserMan.reloadTimer>0:
                    laserMan.reloadTimer-=1
                


                    
                laserMan.Act.image="laserman"
                laserMan.Act.x-=285

                
                        
    for plasmaMan in plasmaMans:
        if plasmaMan.health<0:
            if plasmaMan.Act.image=="dead4":
                plasmaMans.remove(plasmaMan)
            if plasmaMan.Act.image=="dead3":
                plasmaMan.Act.image="dead4"
            if plasmaMan.Act.image=="dead2":
                plasmaMan.Act.image="dead3"
            if plasmaMan.Act.image=="dead1":
                plasmaMan.Act.image="dead2"
            if plasmaMan.Act.image=="plasmaman":
                plasmaMan.Act.image="dead1"
        else:
            if plasmaMan.unit_disabled == True:
                plasmaMan.Act.pos = pygame.mouse.get_pos()
                if keyboard.space:
                    sounds.plasmareload.play()
                    plasmaMan.unit_disabled = False
            else:
                plasmaMan.Act.image="rangedetect"
                plasmaMan.Act.x+=405
                ### detection
                if enemyPlasmaMans == [] and enemyLaserMans==[]:
                    plasmaMan.canmove=True
                else:
                    plasmaMan.canmove=True
                    for enemyPlasmaMan in enemyPlasmaMans:
                        if plasmaMan.reloadTimer == 0 and plasmaMan.Act.colliderect(enemyPlasmaMan.Act):
                            shootPlasma(plasmaMan.Act.x-400,plasmaMan.Act.y)
                            sounds.plasmashot.play()
                            plasmaMan.reloadTimer=175
                        if plasmaMan.Act.colliderect(enemyPlasmaMan.Act):
                            plasmaMan.canmove=False


                            
                    for enemyLaserMan in enemyLaserMans:
                        if plasmaMan.reloadTimer == 0 and plasmaMan.Act.colliderect(enemyLaserMan.Act):
                            shootPlasma(plasmaMan.Act.x-400,plasmaMan.Act.y)
                            sounds.plasmashot.play()
                            plasmaMan.reloadTimer=175
                        if plasmaMan.Act.colliderect(enemyLaserMan.Act):
                            plasmaMan.canmove=False
                            
                    for enemyShockMan in enemyShockMans:
                        if plasmaMan.reloadTimer == 0 and plasmaMan.Act.colliderect(enemyShockMan.Act):
                            shootPlasma(plasmaMan.Act.x-400,plasmaMan.Act.y)
                            sounds.lasershot.play()
                            plasmaMan.reloadTimer=185
                        if enemyShockMan.Act.colliderect(plasmaMan.Act) :
                            plasmaMan.canmove=False

                            
                if plasmaMan.canmove==True:
                    plasmaMan.Act.x+=3

                # reload
                if plasmaMan.reloadTimer>0:
                    plasmaMan.reloadTimer-=1
                if plasmaMan.reloadTimer == 50:
                    sounds.plasmareload.play()
                
                if plasmaMan.health<200:
                    plasmaMan.health+=0.08
            


                
                plasmaMan.Act.image="plasmaman"
                plasmaMan.Act.x-=405                       
    for shockMan in shockMans:
        if shockMan.health<0:
            if shockMan.Act.image=="dead4":
                shockMans.remove(shockMan)
            if shockMan.Act.image=="dead3":
                shockMan.Act.image="dead4"
            if shockMan.Act.image=="dead2":
                shockMan.Act.image="dead3"
            if shockMan.Act.image=="dead1":
                shockMan.Act.image="dead2"
            if shockMan.Act.image=="shockman":
                shockMan.Act.image="dead1"
        else:
            if shockMan.unit_disabled == True:
                shockMan.Act.pos = pygame.mouse.get_pos()
                if keyboard.space:
                    shockMan.unit_disabled = False
                    shockMan.reloadTimer=51
            else:
                shockMan.Act.image="rangedetect"
                shockMan.Act.x+=405
                ### detection
                if enemyPlasmaMans == [] and enemyLaserMans==[]:
                    shockMan.canmove=True
                else:
                    shockMan.canmove=True
                    for enemyPlasmaMan in enemyPlasmaMans:
                        if shockMan.reloadTimer == 0 and shockMan.Act.colliderect(enemyPlasmaMan.Act):
                            shockMan.reloadTimer=175
                        if shockMan.Act.colliderect(enemyPlasmaMan.Act) and shockMan.reloadTimer<10:
                            shootShock(shockMan.Act.x-400,shockMan.Act.y)
                            sounds.shockshot.play()
                        if shockMan.Act.colliderect(enemyPlasmaMan.Act):
                            shockMan.canmove=False  


                            
                    for enemyLaserMan in enemyLaserMans:
                        if shockMan.reloadTimer == 0 and shockMan.Act.colliderect(enemyLaserMan.Act):
                            shockMan.reloadTimer=125
                        if shockMan.Act.colliderect(enemyLaserMan.Act) and shockMan.reloadTimer<10:
                            shootShock(shockMan.Act.x-400,shockMan.Act.y)
                            sounds.shockshot.play()
                        if shockMan.Act.colliderect(enemyLaserMan.Act):
                            shockMan.canmove=False
                    for enemyShockMan in enemyShockMans:
                        if shockMan.reloadTimer == 0 and shockMan.Act.colliderect(enemyShockMan.Act):
                            shockMan.reloadTimer=125
                        if shockMan.Act.colliderect(enemyShockMan.Act) and shockMan.reloadTimer<10:
                            shootShock(shockMan.Act.x-400,shockMan.Act.y)
                            sounds.shockshot.play()
                        if shockMan.Act.colliderect(enemyShockMan.Act):
                            shockMan.canmove=False
                if shockMan.canmove==True:
                    shockMan.Act.x+=3
                    if shockMan.reloadTimer>10:
                        shockMan.reloadTimer-=1
                elif shockMan.reloadTimer>0:
                    shockMan.reloadTimer-=1
                # reload
                if shockMan.reloadTimer==50:
                    sounds.shockreload.play()             
                if shockMan.health<225:
                    shockMan.health+=0.08
            


                
                shockMan.Act.image="shockman"
                shockMan.Act.x-=405

            
            
def shootPlasma(x,y):
        plasma=Actor("plasma1.0")
        plasma.pos=x,y
        plasmas.append(plasma)
def shootLaser(x,y):
    for i in range(0,9):
        laser=Actor("laser")
        laser.pos=(x,y)
        laser.angle=randint(-8,8)
        lasers.append(laser)
def shootShock(x,y):
    for i in range(0,2):
        shock=Actor("shock")
        shock.x=x
        shock.y=randint(y-20,y+20)
        shocks.append(shock)
def shootEnemyShock(x,y):
    for i in range(0,2):
        enemyShock=Actor("shock")
        enemyShock.x=x
        enemyShock.y=randint(y-20,y+20)
        enemyShocks.append(enemyShock)
def shootEnemyLaser(x,y):
    for i in range(0,7):
        enemyLaser=Actor("laser")
        enemyLaser.pos=(x,y)
        enemyLaser.angle=randint(-8+180,8+180)
        enemyLasers.append(enemyLaser)
        
def shootEnemyPlasma(x,y):
        enemyPlasma=Actor("plasma1.0")
        enemyPlasma.pos=x,y
        enemyPlasmas.append(enemyPlasma)
    
def on_mouse_down(pos):
    global money
    if plasmaManBuy.collidepoint(pos) and money>200 or money==200 and laserManBuy.collidepoint(pos):
        money-=200
        spawnPlasmaMan()
    if laserManBuy.collidepoint(pos) and money>225 or money==225 and laserManBuy.collidepoint(pos):
        money-=225
        spawnLaserMan()
    if shockManBuy.collidepoint(pos) and money>325 or money==325 and shockManBuy.collidepoint(pos):
        money-=325
        spawnShockMan()
def update():
    detectKeys()
    update_units()
    update_bullets()
def update_bullets():
    for plasma in plasmas:
        if not plasma.image == "plasmaexplode1" and not plasma.image == "plasmaexplode2" and not plasma.image == "plasmaexplode3" and not plasma.image == "plasmaexplode4" and not plasma.image == "plasmaexplode5" :
            plasma.x+=65
        if not plasma.image == "plasmaexplode1" and not plasma.image == "plasmaexplode2" and not plasma.image == "plasmaexplode3" and not plasma.image == "plasmaexplode4" and not plasma.image == "plasmaexplode5" :
            plasma.image="plasma"+str(plasma.x%4+1)
        if plasma.x > 6000:
            plasmas.remove(plasma)
        for enemyPlasmaMan in enemyPlasmaMans:
            if enemyPlasmaMan.Act.colliderect(plasma) and plasma.image == "plasma"+str(plasma.x%4+1):
                enemyPlasmaMan.health-=30
                sounds.plasmaexplode.play()
                plasma.image="plasmaexplode1"
            elif enemyPlasmaMan.Act.colliderect(plasma) and plasma.image != plasma.x%4+1:
                if enemyPlasmaMan.health>10:
                    enemyPlasmaMan.health-=10
                else:
                    enemyPlasmaMan.health-=10
                    if plasma in plasmas :  
                        plasmas.remove(plasma)
        for enemyLaserMan in enemyLaserMans:
            if enemyLaserMan.Act.colliderect(plasma) and plasma.image == "plasma"+str(plasma.x%4+1):
                enemyLaserMan.health-=30
                sounds.plasmaexplode.play()
                plasma.image="plasmaexplode1"
            elif enemyLaserMan.Act.colliderect(plasma) and plasma.image != plasma.x%4+1:
                if enemyLaserMan.health>10:
                    enemyLaserMan.health-=10
                else:
                    enemyLaserMan.health-=10
                    if plasma in plasmas :
                        plasmas.remove(plasma) 
        if plasma.image == "plasmaexplode5":
            if plasma in plasmas :
                plasmas.remove(plasma) 
        if plasma.image == "plasmaexplode4":
            plasma.image="plasmaexplode5"
        if plasma.image == "plasmaexplode3":
            plasma.image="plasmaexplode4"
        if plasma.image == "plasmaexplode2":
            plasma.image="plasmaexplode3"
        if plasma.image == "plasmaexplode1":
            plasma.image="plasmaexplode2"
    
    for enemyPlasma in enemyPlasmas:
        if not enemyPlasma.image == "plasmaexplode1" and not enemyPlasma.image == "plasmaexplode2" and not enemyPlasma.image == "plasmaexplode3" and not enemyPlasma.image == "plasmaexplode4" and not enemyPlasma.image == "plasmaexplode5":
            enemyPlasma.x-=65
            enemyPlasma.image="plasma"+str(enemyPlasma.x%4+1)
        if enemyPlasma.x < -6000:
            enemyPlasmas.remove(enemyPlasma)
        for plasmaMan in plasmaMans:
            if plasmaMan.Act.colliderect(enemyPlasma) and enemyPlasma.image == "plasma"+str(enemyPlasma.x%4+1) and plasmaMan.unit_disabled==False:
                plasmaMan.health-=25
                sounds.plasmaexplode.play()
                enemyPlasma.image="plasmaexplode1"
            elif plasmaMan.Act.colliderect(enemyPlasma) and enemyPlasma.image != enemyPlasma.x%4+1 and plasmaMan.unit_disabled==False:
                if plasmaMan.health>10:
                    plasmaMan.health-=8
                else:
                    plasmaMan.health-=8
                    if enemyPlasma in enemyPlasmas :
                        enemyPlasmas.remove(enemyPlasma)
        for laserMan in laserMans:
            if laserMan.Act.colliderect(enemyPlasma) and enemyPlasma.image == "plasma"+str(enemyPlasma.x%4+1) and laserMan.unit_disabled==False:
                laserMan.health-=25
                sounds.plasmaexplode.play()
                enemyPlasma.image="plasmaexplode1"
            elif laserMan.Act.colliderect(enemyPlasma) and enemyPlasma.image != enemyPlasma.x%4+1 and laserMan.unit_disabled==False:
                if laserMan.health>10:
                    laserMan.health-=8
                else:
                    laserMan.health-=8
                    if enemyPlasma in enemyPlasmas :
                        enemyPlasmas.remove(enemyPlasma)

        for shockMan in shockMans:
            if shockMan.Act.colliderect(enemyPlasma) and enemyPlasma.image == "plasma"+str(enemyPlasma.x%4+1) and shockMan.unit_disabled==False:
                shockMan.health-=25
                sounds.plasmaexplode.play()
                enemyPlasma.image="plasmaexplode1"
            elif shockMan.Act.colliderect(enemyPlasma) and enemyPlasma.image != enemyPlasma.x%4+1 and shockMan.unit_disabled==False:
                if shockMan.health>10:
                    shockMan.health-=8
                else:
                    shockMan.health-=8
                    if enemyPlasma in enemyPlasmas :
                        enemyPlasmas.remove(enemyPlasma)
                        
        if enemyPlasma.image == "plasmaexplode5":
            if enemyPlasma in enemyPlasmas :
                enemyPlasmas.remove(enemyPlasma)
        if enemyPlasma.image == "plasmaexplode4":
            enemyPlasma.image="plasmaexplode5"
        if enemyPlasma.image == "plasmaexplode3":
            enemyPlasma.image="plasmaexplode4"
        if enemyPlasma.image == "plasmaexplode2":
            enemyPlasma.image="plasmaexplode3"
        if enemyPlasma.image == "plasmaexplode1":
            enemyPlasma.image="plasmaexplode2"
    for laser in lasers:
        if laser.image=="laserdel3":
            lasers.remove(laser)
        if laser.image=="laserdel2":
            laser.image="laserdel3"
        if laser.image=="laserdel":
            laser.image="laserdel2"
        if laser.image=="laser":
            laser.y-=60*math.sin(math.radians(laser.angle))
            laser.x+=60*math.cos(math.radians(laser.angle))
        if laser.x > 6000:
            lasers.remove(laser)
        for enemyPlasmaMan in enemyPlasmaMans:
            if enemyPlasmaMan.health>0 and laser.colliderect(enemyPlasmaMan.Act) and laser.image=="laser":
                enemyPlasmaMan.health-=12
                sounds.laserhit.play()
                laser.image="laserdel"
        for enemyLaserMan in enemyLaserMans:
            if enemyLaserMan.health>0 and laser.colliderect(enemyLaserMan.Act)and laser.image=="laser":
                enemyLaserMan.health-=12
                sounds.laserhit.play()
                laser.image="laserdel"
                
    for shock in shocks:
        if shock.image=="shockexplode3":
            shocks.remove(shock)
        if shock.image=="shockexplode":
            shock.image="shockexplode3"
        if shock.image=="shockexplode":
            shock.image="shockexplode"
        if shock.image=="shock":
            shock.x+=60
        for enemyPlasmaMan in enemyPlasmaMans:
            if enemyPlasmaMan.health>0 and shock.colliderect(enemyPlasmaMan.Act) and shock.image=="shock":
                enemyPlasmaMan.health-=4
                sounds.shockhit.play()
                shock.image="shockexplode"
        for enemyLaserMan in enemyLaserMans:
            if enemyLaserMan.health>0 and shock.colliderect(enemyLaserMan.Act)and shock.image=="shock":
                enemyLaserMan.health-=4
                sounds.shockhit.play()
                shock.image="shockexplode"
        if shock.x > 6000:
            shocks.remove(shock)                
    for enemyLaser in enemyLasers:
        if enemyLaser.image=="laserdel3":
            enemyLasers.remove(enemyLaser)
        if enemyLaser.image=="laserdel2":
           enemyLaser.image="laserdel3"
        if enemyLaser.image=="laserdel":
           enemyLaser.image="laserdel2" 
        if enemyLaser.image=="laser":            
            enemyLaser.y-=60*math.sin(math.radians(enemyLaser.angle))
            enemyLaser.x+=60*math.cos(math.radians(enemyLaser.angle))
        for plasmaMan in plasmaMans:
            if plasmaMan.health>0 and enemyLaser.colliderect(plasmaMan.Act) and plasmaMan.unit_disabled==False and enemyLaser.image=="laser":
                plasmaMan.health-=9
                sounds.laserhit.play()
                enemyLaser.image="laserdel"
        for laserMan in laserMans:
            if laserMan.health>0 and enemyLaser.colliderect(laserMan.Act) and enemyLaser.image=="laser" and laserMan.unit_disabled==False:
                laserMan.health-=9
                sounds.laserhit.play()
                enemyLaser.image="laserdel"
        for shockMan in shockMans:
            if shockMan.health>0 and enemyLaser.colliderect(shockMan.Act) and enemyLaser.image=="laser" and shockMan.unit_disabled==False:
                shockMan.health-=9
                sounds.laserhit.play()
                enemyLaser.image="laserdel"
        if enemyLaser.x < -6000:
            enemyLasers.remove(enemyLaser)
def draw():
    screen.clear()
    Background.draw()
    playerTower.draw()
    goldIcon.draw()
    # Warning! do NOT add things above here
    # // draw health bars
    if playerTowerHealth!=300 and playerTowerHealth>-1:
      RED = 180, 0, 0
      BOX = Rect((playerTower.x-160+playerTowerHealth, playerTower.y-75), (300+(playerTowerHealth*-1) ,10))
      screen.draw.filled_rect(BOX, RED)
    elif playerTowerHealth<0:
      RED = 180, 0, 0
      BOX = Rect((playerTower.x-160, playerTower.y-75), (300, 10))
      screen.draw.filled_rect(BOX, RED)         
    if playerTowerHealth>0:
      RED = 0, 190, 0
      BOX = Rect((playerTower.x-160, playerTower.y-75), (playerTowerHealth, 10))
      screen.draw.filled_rect(BOX, RED)
#    screen.draw.text(str(money),topleft=(45,5),fontsize=35)
    for enemyPlasmaMan in enemyPlasmaMans:
        enemyPlasmaMan.Act.draw()
        if enemyPlasmaMan.health!=140 and enemyPlasmaMan.health>-1:
          RED = 180, 0, 0
          BOX = Rect((enemyPlasmaMan.Act.x-70+enemyPlasmaMan.health, enemyPlasmaMan.Act.y-35), (140+(enemyPlasmaMan.health*-1) ,10))
          screen.draw.filled_rect(BOX, RED)
        if enemyPlasmaMan.health<0:
          RED = 180, 0, 0
          BOX = Rect((enemyPlasmaMan.Act.x-70, enemyPlasmaMan.Act.y-35), (140, 10))
          screen.draw.filled_rect(BOX, RED)         
        if enemyPlasmaMan.health>0:
          RED = 0, 190, 0
          BOX = Rect((enemyPlasmaMan.Act.x-70, enemyPlasmaMan.Act.y-35), (enemyPlasmaMan.health, 10))
          screen.draw.filled_rect(BOX, RED)
          
    for plasmaMan in plasmaMans:
        plasmaMan.Act.draw()
        if plasmaMan.health!=200 and plasmaMan.health>-1:
          RED = 180, 0, 0
          BOX = Rect((plasmaMan.Act.x-100+plasmaMan.health, plasmaMan.Act.y-35), (200+(plasmaMan.health*-1) ,10))
          screen.draw.filled_rect(BOX, RED)
        if plasmaMan.health<0:
          RED = 180, 0, 0
          BOX = Rect((plasmaMan.Act.x-100, plasmaMan.Act.y-35), (200, 10))
          screen.draw.filled_rect(BOX, RED)         
        if plasmaMan.health>0:
          RED = 0, 190, 0
          BOX = Rect((plasmaMan.Act.x-100, plasmaMan.Act.y-35), (plasmaMan.health, 10))
          screen.draw.filled_rect(BOX, RED)

    for shockMan in shockMans:
        shockMan.Act.draw()
        if shockMan.health!=225 and shockMan.health>-1:
          RED = 180, 0, 0
          BOX = Rect((shockMan.Act.x-100+shockMan.health, shockMan.Act.y-35), (225+(shockMan.health*-1) ,10))
          screen.draw.filled_rect(BOX, RED)
        if shockMan.health<0:
          RED = 180, 0, 0
          BOX = Rect((shockMan.Act.x-100, shockMan.Act.y-35), (225, 10))
          screen.draw.filled_rect(BOX, RED)         
        if shockMan.health>0:
          RED = 0, 190, 0
          BOX = Rect((shockMan.Act.x-100, shockMan.Act.y-35), (shockMan.health, 10))
          screen.draw.filled_rect(BOX, RED)

    for laserMan in laserMans:
        laserMan.Act.draw()
        if laserMan.health!=225 and laserMan.health>-1:
          RED = 180, 0, 0
          BOX = Rect((laserMan.Act.x-100+laserMan.health, laserMan.Act.y-35), (225+(laserMan.health*-1) ,10))
          screen.draw.filled_rect(BOX, RED)
        if laserMan.health<0:
          RED = 180, 0, 0
          BOX = Rect((laserMan.Act.x-100, laserMan.Act.y-35), (225, 10))
          screen.draw.filled_rect(BOX, RED)         
        if laserMan.health>0:
          RED = 0, 190, 0
          BOX = Rect((laserMan.Act.x-100, laserMan.Act.y-35), (laserMan.health, 10))
          screen.draw.filled_rect(BOX, RED)

    for enemyLaserMan in enemyLaserMans:
        enemyLaserMan.Act.draw()
        if enemyLaserMan.health!=200 and enemyLaserMan.health>-1:
          RED = 180, 0, 0
          BOX = Rect((enemyLaserMan.Act.x-100+enemyLaserMan.health, enemyLaserMan.Act.y-35), (200+(enemyLaserMan.health*-1) ,10))
          screen.draw.filled_rect(BOX, RED)
        if enemyLaserMan.health<0:
          RED = 180, 0, 0
          BOX = Rect((enemyLaserMan.Act.x-100, enemyLaserMan.Act.y-35), (200, 10))
          screen.draw.filled_rect(BOX, RED)         
        if enemyLaserMan.health>0:
          RED = 0, 190, 0
          BOX = Rect((enemyLaserMan.Act.x-100, enemyLaserMan.Act.y-35), (enemyLaserMan.health, 10))
          screen.draw.filled_rect(BOX, RED)
    for enemyShockMan in enemyShockMans:
        enemyShockMan.Act.draw()        
        if enemyShockMan.health!=200 and enemyShockMan.health>-1:
          RED = 180, 0, 0
          BOX = Rect((enemyShockMan.Act.x-100+enemyShockMan.health, enemyShockMan.Act.y-35), (200+(enemyShockMan.health*-1) ,10))
          screen.draw.filled_rect(BOX, RED)
        if enemyShockMan.health<0:
          RED = 180, 0, 0
          BOX = Rect((enemyShockMan.Act.x-100, enemyShockMan.Act.y-35), (200, 10))
          screen.draw.filled_rect(BOX, RED)         
        if enemyShockMan.health>0:
          RED = 0, 190, 0
          BOX = Rect((enemyShockMan.Act.x-100, enemyShockMan.Act.y-35), (enemyShockMan.health, 10))
          screen.draw.filled_rect(BOX, RED)
# list for loops    
    for plasma in plasmas:
        plasma.draw()
    for laser in lasers:
        laser.draw()
    for shock in shocks:
        shock.draw()
    plasmaManBuy.draw()
    laserManBuy.draw()
    shockManBuy.draw()
    for enemyPlasma in enemyPlasmas:
        enemyPlasma.draw()
    for enemyLaser in enemyLasers:
        enemyLaser.draw()

def detectKeys():   
    global Backgroud
    if  keyboard.LEFT and Background.x < 1900:
        for plasma in plasmas:  
            plasma.x+=6
        for plasmaMan in plasmaMans:
            plasmaMan.Act.x+=6
        for laser in lasers:
            laser.x+=6
        for shock in shocks:
            shock.x+=6
        Background.x += 6
        playerTower.x  += 6
        for enemyPlasmaMan in enemyPlasmaMans:
            enemyPlasmaMan.Act.x+=6
        for enemyLaserMan in enemyLaserMans:
            enemyLaserMan.Act.x+=6
        for enemyPlasma in enemyPlasmas:
            enemyPlasma.x-=6
        for laserMan in laserMans:
            laserMan.Act.x+=6
        for shockMan in shockMans:
            shockMan.Act.x+=6
        for enemyShockMan in enemyShockMans:
            enemyShockMan.Act.x+=6
    if keyboard.RIGHT and Background.x > 6:
        for plasma in plasmas:
            plasma.x-=6
        for shock in shocks:
            shock.x-=6
        for enemyPlasma in enemyPlasmas:
            enemyPlasma.x-=6
        for shockMan in shockMans:
            shockMan.Act.x-=6
        for laser in lasers:
            laser.x-=6
        for plasmaMan in plasmaMans:
            plasmaMan.Act.x-=6
        for enemyPlasmaMan in enemyPlasmaMans:
            enemyPlasmaMan.Act.x-=6
        for enemyLaserMan in enemyLaserMans:
            enemyLaserMan.Act.x-=6
        for enemyShockMan in enemyShockMans:
            enemyShockMan.Act.x-=6
        for laserMan in laserMans:
            laserMan.Act.x-=6
        Background.x -= 6
        playerTower.x  -= 6
def saveData():
    pass
pgzrun.go()
